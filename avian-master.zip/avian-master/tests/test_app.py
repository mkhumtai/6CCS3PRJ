# Checks if new users details are stored correctly
def test_new_user(new_user):
    assert new_user.user == 'staff1'
    assert new_user.email == 'staff1@gmail.com'
    assert new_user.hashed_password != 'testingpassword'


# Checks if client exists
def test_client_exists(client):
    assert client is not None


# Checks if a wrong url returns a correct error page
def test_wrong_url(client):
    response = client.get('/wrongurl.html')
    assert response.status_code == 302


# Checks if register page can be accessed correctly
def test_register_page(client):
    response = client.get('/register.html')
    assert response.status_code == 200
    assert b'Register' in response.data


# Checks if correct pages requires login from users
def test_login_required(client):
    ana = client.get('/analysis.html')
    view = client.get('/viewEmpres.html')
    assert ana.status_code == 401
    assert view.status_code == 401


# Checks if users are redirected when accessing /index.html
def test_redirect(client):
    response = client.get('/index.html')
    assert response.status_code == 308


# Checks if users with valid login is redirected correctly
def test_valid_login(client):
    response = client.post('/login.html', data=dict(user='user', password='password'),
                           follow_redirects=True)
    assert response.status_code == 200


# Checks if users with invalid login remains in login page
def test_invalid_login(client):
    response = client.post('/login.html', data=dict(user='fake_user', password='fake_password'),
                           follow_redirects=True)
    assert b'username' in response.data
    assert b'password' in response.data
