import pandas as pd

from app.dbscan import dbscan
from app.kmeans import kmeans
from app.cleanEmpress import find_species_and_types

data = {'Id': [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11],
        'latitude': [-6.500000, 31.416670, 20.833060, 19.800000, -8.541300, 0.266670, -6.174440, -6.187137,
                     -8.456016, -6.187137,
                     -6.863998, -7.873252],
        'longitude': [106.250000, 31.800000, 105.666670, 105.766670, 115.125217, 101.683060, 106.829440, 106.465560,
                      115.270325, 106.46556, 107.616626, 110.413375],
        'quarters': ['2007Q3', '2007Q3', '2007Q3', '2007Q3', '2007Q3', '2007Q3', '2007Q3', '2007Q3', '2007Q3',
                     '2008Q3',
                     '2012Q3', '2012Q3']}
df = pd.DataFrame(data)
grouped = [pd.DataFrame(y) for x, y in df.groupby('quarters', as_index=False)]


# Checks if dbscan returns the correct dataframe
def test_dbscan_dfs():
    dfs, hov = dbscan(grouped)
    assert dfs.values.tolist() == [[7, -6.187137, 106.46556, '2007Q3'],
                                   [1, 31.41667, 31.8, '2007Q3'], [2, 20.83306, 105.66667, '2007Q3'],
                                   [4, -8.5413, 115.125217, '2007Q3'], [5, 0.26667, 101.68306, '2007Q3'],
                                   [10, -6.863998, 107.616626, '2012Q3'], [11, -7.873252, 110.413375, '2012Q3']]


# Checks if dbscan returns the correct silhouette and compression value
def test_dbscan_hov():
    dfs, hov = dbscan(grouped)
    assert hov == [
        '2007Q3 Silhouette coefficient: 0.743,  Clustered 9 points down to 5 clusters, for 44.4% compression',
        '2012Q3No points clustered, Number of clusters: 2']


# Checks if kmeans returns the correct silhouette and compression value
def test_kmeans_hov():
    dfs, hover = kmeans(grouped)
    assert hover == ['2007Q3Silhouette coefficient: 0.743,  Clustered 9 points down to 5 clusters, for 44.4% '
                     'compression']


# Checks if kmeans disregard quarters with data less than 3
def test_min_kmeans():
    min_data = {'Id': [0, 1, 2, 3, 4, 5],
            'latitude': [-6.500000, 31.416670, 20.833060, 19.800000, -8.541300, 21.453245],
            'longitude': [106.250000, 31.800000, 105.666670, 105.766670, 115.125217, 102.443251],
            'quarters': ['2007Q3', '2007Q3', '2008Q3', '2008Q3', '2008Q3', '2008Q3']}
    min_df = pd.DataFrame(min_data)
    min_grouped = [pd.DataFrame(y) for x, y in min_df.groupby('quarters', as_index=False)]
    dfs_k, hov_k = kmeans(min_grouped)
    assert dfs_k.shape == (4, 5)


# Checks if find_species_and_types is able to split a column correctly
def test_empres():
    lst = [['wild, unspecified bird, domestic, chicken, domestic, turkey'],
           ['domestic, chicken'],
           ['wild, goose, domestic, unspecified bird, domestic, turkey']]
    res = [find_species_and_types(x[0]) for x in lst]
    # Handles issue that first finding will either be 'domestic, wild' or 'wild, domestic'
    if res[0][0] == 'domestic, wild':
        assert res == [('domestic, wild', 'unspecified bird, chicken, turkey'), ('domestic', 'chicken'),
                       ('domestic, wild', 'goose, unspecified bird, turkey')]
    else:
        assert res == [('wild, domestic', 'unspecified bird, chicken, turkey'), ('domestic', 'chicken'),
                       ('wild, domestic', 'goose, unspecified bird, turkey')]
